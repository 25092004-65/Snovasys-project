# AI assistance log

> Replace these examples with the prompts you actually use during the hackathon. Keep dates accurate and add the related commit URL. Do not claim AI output was used if it was not.

## Entry 1 — 2026-11-06
- Prompt summary: Create a beginner-friendly FastAPI and React project structure.
- AI output: Suggested a layered backend, React frontend, and local setup steps.
- Specific problem: Needed a starting architecture.
- What I did instead: Reviewed the structure and adapted it to the hackathon requirements.
- Commit link: TODO

## Entry 2 — 2026-11-06
- Prompt summary: Design server-side per-document authorization.
- AI output: Suggested checking ownership or a permission row for every document request.
- Specific problem: Prevent IDOR / insecure direct object reference.
- What I did instead: Added backend permission checks and tests for cross-user downloads.
- Commit link: TODO

## Entry 3 — 2026-11-06
- Prompt summary: Design immediate permission revocation.
- AI output: Suggested querying the current permission table on each download instead of trusting cached JWT claims.
- Specific problem: Previously granted users must lose access immediately after revocation.
- What I did instead: Added a revoke endpoint and a test that retries the download after revocation.
- Commit link: TODO

## Entry 4 — 2026-11-06
- Prompt summary: Create a hash-chained audit log.
- AI output: Suggested linking each audit row to the previous row's hash.
- Specific problem: Detect changes to audit records.
- What I did instead: Added a verification endpoint and documented the limitation of a database-only hash chain.
- Commit link: TODO

## Entry 5 — 2026-11-06
- Prompt summary: Write threat scenarios and security tests.
- AI output: Suggested threats including IDOR, unauthorized upload, revoked access, and audit tampering.
- Specific problem: Prepare for judge security testing.
- What I did instead: Added a threat table and ran the tests locally.
- Commit link: TODO
