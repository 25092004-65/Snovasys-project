import { useEffect, useState } from 'react';
import { request, API, getToken } from './services/api';

export default function App() {
  const [user, setUser] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [mode, setMode] = useState('login');
  const [docs, setDocs] = useState([]);
  const [message, setMessage] = useState('');
  const [query, setQuery] = useState('');
  const [audit, setAudit] = useState([]);

  async function loadMe() {
    if (!getToken()) return;
    try { const r = await request('/auth/me'); setUser(await r.json()); }
    catch { localStorage.removeItem('trustvault_token'); }
  }
  async function loadDocs() {
    try { const r = await request(`/documents?q=${encodeURIComponent(query)}`); setDocs(await r.json()); }
    catch(e) { setMessage(e.message); }
  }
  useEffect(() => { loadMe(); }, []);
  useEffect(() => { if (user) loadDocs(); }, [user, query]);

  async function authenticate(e) {
    e.preventDefault(); setMessage('');
    try {
      const path = mode === 'login' ? '/auth/login' : '/auth/register';
      const payload = mode === 'login' ? {email, password} : {email, password, full_name: name};
      const r = await fetch(`${API}${path}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
      const data = await r.json();
      if (!r.ok) throw new Error(data.detail || 'Authentication failed');
      localStorage.setItem('trustvault_token', data.access_token);
      setUser(data.user); setMessage('Welcome to TrustVault');
    } catch(e) { setMessage(e.message); }
  }
  async function upload(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    try { await request('/documents/upload', {method:'POST', body:form}); setMessage('Document uploaded'); e.target.reset(); loadDocs(); }
    catch(e) { setMessage(e.message); }
  }
  async function download(id) {
    try {
      const r = await request(`/documents/${id}/download`);
      const blob = await r.blob(); const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = docs.find(d=>d.id===id)?.name || 'document';
      a.click(); URL.revokeObjectURL(url);
    } catch(e) { setMessage(e.message); }
  }
  async function grant(e, id) {
    e.preventDefault(); const form = new FormData(e.target);
    try { await request(`/documents/${id}/permissions`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email:form.get('email'), permission:form.get('permission')})}); setMessage('Access granted'); e.target.reset(); }
    catch(e) { setMessage(e.message); }
  }
  async function loadAudit() {
    try { const r=await request('/admin/audit'); setAudit(await r.json()); }
    catch(e) { setMessage(e.message); }
  }
  function logout(){ localStorage.removeItem('trustvault_token'); setUser(null); setDocs([]); }

  if (!user) return <main className="auth"><section className="panel"><h1>🔐 TrustVault</h1><p>Secure document sharing with a real audit trail</p>
    <form onSubmit={authenticate}>
      {mode==='register' && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} required /></label>}
      <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required /></label>
      <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength="8" /></label>
      <button>{mode==='login'?'Login':'Create account'}</button>
    </form>
    <p><button className="link" onClick={()=>setMode(mode==='login'?'register':'login')}>{mode==='login'?'Create an account':'Back to login'}</button></p>
    {message && <p className="message">{message}</p>}
  </section></main>;

  return <main className="wrap"><header><div><h1>🔐 TrustVault</h1><p>{user.full_name} · {user.role}</p></div><button className="secondary" onClick={logout}>Logout</button></header>
    {message && <p className="message">{message}</p>}
    <section className="panel"><h2>My document workspace</h2><input placeholder="Search by file name" value={query} onChange={e=>setQuery(e.target.value)} />
      {(user.role==='owner'||user.role==='admin') && <form className="upload" onSubmit={upload}><h3>Upload document</h3><input type="file" name="file" required /><input name="category" placeholder="Category (e.g. Reports)" /><button>Upload</button></form>}
      <div className="documents">{docs.map(doc=><article className="doc" key={doc.id}><div><b>{doc.name}</b><small>{doc.category} · {Math.round(doc.size_bytes/1024)} KB</small></div><button onClick={()=>download(doc.id)}>Download</button>
        {doc.owner_id===user.id && <details><summary>Share access</summary><form onSubmit={e=>grant(e,doc.id)}><input name="email" type="email" placeholder="Registered user's email" required/><select name="permission"><option value="read">Read</option><option value="write">Write</option></select><button>Grant</button></form></details>}
      </article>)}</div>
    </section>
    {user.role==='admin' && <section className="panel"><h2>Admin audit activity</h2><button onClick={loadAudit}>Load audit events</button>{audit.map(x=><p className="audit" key={x.id}>#{x.id} · {x.action} · user {x.actor_id ?? 'unknown'} · {x.success?'Success':'Denied'}</p>)}</section>}
    <p className="foot">Access is checked by the server for every document request.</p>
  </main>;
}
