const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
export function getToken(){ return localStorage.getItem('trustvault_token'); }
export async function request(path, options = {}) {
  const headers = {...(options.headers || {})};
  if (getToken()) headers.Authorization = `Bearer ${getToken()}`;
  const response = await fetch(`${API}${path}`, {...options, headers});
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.detail || 'Request failed');
  }
  return response;
}
export { API };
