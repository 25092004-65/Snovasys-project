# TrustVault — Secure document sharing with a real audit trail

Beginner-friendly hackathon starter using React + FastAPI + PostgreSQL-compatible SQLAlchemy.

## 1. Requirements
- Python 3.11+
- Node.js 20+
- Git

## 2. Start backend (Windows PowerShell)
```powershell
cd TrustVault
cd backend
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```
Open `.env` and replace `SECRET_KEY` with a long random value. Then:
```powershell
uvicorn app.main:app --reload
```
API docs: http://127.0.0.1:8000/docs

macOS/Linux activation: `source .venv/bin/activate`.

## 3. Start frontend (new terminal)
```powershell
cd TrustVault/frontend
npm install
Copy-Item .env.example .env
npm run dev
```
Open http://localhost:5173.

## 4. Create an owner account for local demo
Public signup deliberately creates viewer accounts only. To promote a test account to owner, stop the backend after registering, then run this from `backend` with the virtual environment active:
```powershell
python -c "from app.database import SessionLocal; from app.models import User; db=SessionLocal(); u=db.query(User).filter_by(email='YOUR_EMAIL').first(); u.role='owner'; db.commit(); db.close()"
```
Log out and log back in to receive a token with the updated role. For a demo admin, change role to `admin` in the same command. Do not expose this database shortcut in production.

## 5. Run tests
From `backend`:
```powershell
pytest -q
```

## 6. Main API routes
| Method | Route | Allowed user |
|---|---|---|
| POST | `/auth/register` | Public (creates viewer only) |
| POST | `/auth/login` | Public |
| GET | `/auth/me` | Any logged-in user |
| POST | `/documents/upload` | Owner, Admin |
| GET | `/documents` | Logged-in users; returns only visible docs |
| GET | `/documents/{id}/download` | Owner or explicitly permitted user |
| DELETE | `/documents/{id}` | Document owner |
| POST | `/documents/{id}/permissions` | Document owner |
| DELETE | `/documents/{id}/permissions/{user_id}` | Document owner |
| GET | `/admin/audit` | Admin |
| GET | `/admin/audit/verify` | Admin |

## 7. Important security notes
- Do not make `private_uploads` public.
- Do not put secrets in Git. Add `.env` to `.gitignore` before pushing.
- This starter is a learning baseline, not a production security certification.
- For production, add database migrations, rate limiting, MFA, malware scanning, file-signature validation, backups, persistent private object storage, and externally anchored audit hashes.
- Audit events are hash chained, but a privileged attacker who can rewrite the entire database can recompute the chain. External anchoring is needed for stronger tamper evidence.

## 8. Deployment outline
1. Provision a managed PostgreSQL database.
2. Deploy `backend` as a Python web service. Set `DATABASE_URL`, `SECRET_KEY`, `FRONTEND_ORIGIN`, `UPLOAD_DIR`, and `MAX_UPLOAD_MB`.
3. Attach persistent private storage to the backend at the configured `UPLOAD_DIR`, or replace local disk storage with a private object-storage bucket.
4. Deploy `frontend` as a static site. Set `VITE_API_URL` to the backend HTTPS URL.
5. Update `FRONTEND_ORIGIN` to the exact frontend URL.
6. Test login, unauthorized download, grant, revoke, and audit verification on the live deployment.

## 9. Before hackathon submission
- Add migrations (Alembic) instead of relying on `create_all`.
- Add admin-only user-role management and seed scripts.
- Add audit events for permission-denied list/search, delete failures, and all admin actions.
- Add file signature checks, rate limiting, malware scanning, pagination, and database indexes.
- Add tests for unauthenticated access, wrong roles, upload validation, permission changes, audit-chain tampering, and document ID guessing.
- Replace demo role-promotion instructions with a secure one-time admin bootstrap.
- Complete `THREATS.md` and `PROMPTS.md` using actual work and commit links.
