# TrustVault threat model

## Assets
- Document bytes and metadata
- User credentials and JWTs
- Per-document permissions
- Audit events

## Threat scenarios and mitigations

| Threat | Mitigation | Test |
|---|---|---|
| Viewer changes document ID in URL | Backend checks ownership/permission on every download | `test_private_document_not_visible_to_other_user` |
| Revoked user reuses old URL | Permission is read from DB on every request; no long-lived public links | `test_revoke_access_blocks_next_download` |
| Unauthenticated API access | JWT required for protected routes | Add/extend auth tests |
| Viewer uploads a file | Role check on upload endpoint | `test_viewer_cannot_upload` |
| Dangerous file extension or MIME mismatch | Allowlist extension + MIME, size limit, server-generated storage name | Upload validation tests recommended |
| User guesses another document's existence | Return 404 for missing and unauthorized documents | Security tests |
| Audit row is modified | Hash chain detects edits/deletions/reordering | Admin `/admin/audit/verify` |
| XSS through file name | React escapes text; never render file names as HTML | Frontend review |
| Brute-force login | Production rate limiting and monitoring required | Not included in starter |
| Database/storage administrator tampers with all audit rows | Hash chain alone is not sufficient against privileged full rewrite; periodically anchor latest hash in separate trusted storage | Accepted risk in starter |

## Security decisions
- Public signup always creates `viewer`; role elevation must be done by a trusted administrator through a controlled provisioning process.
- Admin role does not automatically grant access to document contents.
- Only the owner grants/revokes document permissions.
- A revoked permission is checked against the database on the next request.
- Private files are not served from a public static directory.
- Denied downloads are recorded in the audit table.

## Accepted limitations before production
- The starter does not include malware scanning, rate limiting, MFA, external audit-hash anchoring, or a full administrator user-management screen.
- File content validation uses extension/MIME allowlists, not deep file signature inspection.
- The local file system is for development only; production requires persistent private storage and backups.
